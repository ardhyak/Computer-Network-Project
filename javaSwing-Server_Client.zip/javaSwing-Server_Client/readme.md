# Client Server File Transfer 

Build 1.0

###### Client Server File Transfer is a java application that is used to chat using java environment.
###### Client Server File Transfer has been developed using Netbeans IDE.
    

### Installation

Client Server File Transfer requires functional [Netbeans IDE](https://netbeans.org/)  to run.

- Open ChatClient.class file under build>classes>com>kunal 
A window will show up select 'Server' and proceed.

- Open ClientServer.class file under build>classes>com>kunal 
Run the ClietServer.java file to establish a client.

  You will see a window prompting to enter server address
  Enter your ip address (you can find it using ipconfig on command line).

  A window will show up prompting to enter your name.
  Enter it as follows

```sh
Enter your name.
Welcome kunal to our chat room.
To leave enter /quit in a new line.
```
  Similarly establish another client and enter a name
  
```sh
Enter your name.
Welcome anshul to our chat room.
To leave enter /quit in a new line.
```
Now you can chat in the thread.

- The current limit is set to be as 10 for clients in common thread this can be increased by
Opening MultiThreadChatServerSync.class under build>classes>com>kunal and modifying the integer field in:
```sh
private static final int maxClientsCount = 10; \\ line no 22
```
